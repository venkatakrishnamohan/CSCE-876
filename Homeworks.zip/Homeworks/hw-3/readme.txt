The file name is Simplereflex.java and is programmed using Java programming
language. This file can be run on any machine with Java installed on it.
Open Terminal/command prompt on your machine and go to the directory where 
this file is saved. Now type
javac Simplereflex.java ---> This compiles the file and generates class files.
java Simplereflex -----> This runs the class file and produces output.

This program runs a function which takes arguments as any one of the 8 possibles states of a
simple reflex agent and runs until the goal state is reached.

This program displays the state of simple reflex agent and the actions, intermediate
states present while approaching the goal state. It also represents the number of steps taken
for acheiving the goal as performance measure. The state with highest performance measure is
considered as best state as it approaches to goal state in less number of steps.